# epistemic-gestalt-switch
A conceptual, biosemiotic-inspired security framework designed to identify and dismantle parasitic, self-detrimental feedback loops through epistemic paradigm shifts. to help direct a Kuhnian paradigm shift within an entity or system.
