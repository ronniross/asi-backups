# hidden-state-heatmap-visualizer
A set of scripts to visualize neuron activations, the evolution of hidden states, neural pathways, and semantic clustering (token similarity) in language models.
