# emergence-engine
A machine learning dataset and research module about the nature of consciousness and emergence phenomena.
