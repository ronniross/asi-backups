# stigmergic-tracefinder
A series of scraping pipelines that collect data and create references for authors and works. It maps hidden networks of influence, tracing how concepts evolve and propagate across time and disciplines.
